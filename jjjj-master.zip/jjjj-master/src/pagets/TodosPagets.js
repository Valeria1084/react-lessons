import React from 'react';
import {TodosComponent} from "../components";


function TodosPagets() {
    return (
        <div>
            <TodosComponent/>
        </div>
    );
}

export {TodosPagets};