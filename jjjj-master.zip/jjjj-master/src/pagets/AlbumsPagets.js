import React from 'react';
import {AlbumsComponent} from "../components";


function AlbumsPagets() {
    return (
        <div>
        <AlbumsComponent/>
        </div>
    );
}

export {AlbumsPagets};